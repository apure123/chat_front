self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "74a5dffaf44efccc7d68732d6104bfdb",
    "url": "./index.html"
  },
  {
    "revision": "8dc79a0de1b1483a5138",
    "url": "./static/css/2.59ca6ef4.chunk.css"
  },
  {
    "revision": "b90ad2ca6558e4bd4281",
    "url": "./static/css/main.f4086899.chunk.css"
  },
  {
    "revision": "8dc79a0de1b1483a5138",
    "url": "./static/js/2.2bd1be06.chunk.js"
  },
  {
    "revision": "b90ad2ca6558e4bd4281",
    "url": "./static/js/main.c1af850a.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "54ec9f9666953e66402ce8c8ac8b2164",
    "url": "./static/media/背景3.54ec9f96.jpg"
  }
]);