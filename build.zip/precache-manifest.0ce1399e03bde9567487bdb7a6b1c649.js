self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c04f259d4433c10a41848aac55e74aee",
    "url": "./index.html"
  },
  {
    "revision": "83eea85ab8357020e248",
    "url": "./static/css/2.59ca6ef4.chunk.css"
  },
  {
    "revision": "7aa0125cad22b8f5ad87",
    "url": "./static/css/main.d406d556.chunk.css"
  },
  {
    "revision": "83eea85ab8357020e248",
    "url": "./static/js/2.6e3ba449.chunk.js"
  },
  {
    "revision": "7aa0125cad22b8f5ad87",
    "url": "./static/js/main.a6d30940.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "d04844573defffeac268366b175c0f0d",
    "url": "./static/media/登录1.d0484457.jpg"
  }
]);